# Jago Da2 — Web3 Community Manager Portfolio

A static, deployable personal portfolio. Open `index.html` in a browser to preview it, or upload these files to Netlify, Vercel, GitHub Pages, or any static web host.

## Add the signature PFP

Replace the `div` with class `pfp-placeholder` in `index.html` with an image element such as:

```html
<img class="pfp-image" src="assets/jago-stickman-pfp.png" alt="Jago Da2's signature stickman profile image" />
```

Then add your image at `assets/jago-stickman-pfp.png` and add suitable CSS for `.pfp-image`.
